//<csscript>

//  <nodebug/>

//  <references>

//    <reference>System</reference>

//    <reference>System.Core</reference>

//    <reference>System.Data</reference>

//    <reference>System.Data.DataSetExtensions</reference>

//    <reference>System.Xml</reference>

//    <reference>System.Xml.Linq</reference>

//    <reference>System.Windows.Forms</reference>

//    <reference>System.Drawing</reference>

//  </references>

//  <mode>winexe</mode>

//Copied from: Weekend Scripter: Run C# Code from Within PowerShell | Scripting Blog - 2020-09-15 14:44:37 - <https://devblogs.microsoft.com/scripting/weekend-scripter-run-c-code-from-within-powershell/>


public Split(String[] args)
    {
        //if (args.Length != 4) 
        if (args.Length != 1) 
        {

            // we don't need this errormessage we only want 1 parameter, filepath
            // should only warn case no bookmarks detected 
            //0 srcfile - self explenatory
            //1 destfile1 - projectPath (no input)
            //2 destfile2 - not relevant
            //3 pagenumber - not relevant

            Console.Error.WriteLine(
                //"This tools needs 4 parameters:\njava Split srcfile destfile1 destfile2 pagenumber"
                "This tools needs 1 parameters:\nsrcfile"               
                );
        }
        else 
        {
            try 
            {            
                //
                //Copied from: PDFsharp & MigraDoc Foundation • View topic - Find out page number from bookmark entries and split - 2020-09-15 12:08:00 - <https://forum.pdfsharp.net/viewtopic.php?f=2&t=3663>
                using (PdfDocument inputDocument = PdfReader.Open(args[0], PdfDocumentOpenMode.Import))
                {
                    File.Copy(Path.Combine("../../../../../PDFs/", args[0]),Path.Combine(Directory.GetCurrentDirectory(), args[0]), true);   
                    string inputName = Path.GetFileNameWithoutExtension(args[0]); // i like the syntax, makes more sense than the powershell way    
                    PdfDictionary outline = inputDocument.Internals.Catalog.Elements.GetDictionary("/Outlines");         


                    //itterate over bookmarks                                           
                    //how do we identify 
                   
                    for (PdfDictionary childZ = outline.Elements.GetDictionary("/First"); child != null; child = child.Elements.GetDictionary("/Next"))
                    {
                        
                        //identifiera vilka sidor som // tror inte att vi kan använda en for loop här // som jag ser det finns inget värde för pageCount // verkar som att det recomenderas att använda GetEnumerator // vilket inte bör vara extremt svårt //for (int idx = 0; idx < child.PageCount; idx++)
                        
                        PdfDocument outputDocument;
                        string bookMarkName = "";
                        
                        foreach (ref readonly var child in childZ)
                        {
                            if(bookMarkName = "")
                            {
                                bookMarkName = child.values[0]
                                // Create new document
                                PdfDocument outputDocument = new PdfDocument(); outputDocument.Version = inputDocument.Version;

                                //bookmark should be title
                                outputDocument.Info.Title = bookMarkName;
                                outputDocument.Info.Creator = inputDocument.Creator;
                                 
                                // Add the page and save it
                                outputDocument.AddPage(child);
                            }
                            else if(bookMarkName != child.values[0] AND bookMarkName != "")
                            {
                                outputDocument.Save(String.Format("{0}_tempfile.pdf", bookMarkName));                
                             
                                bookMarkName = child.values[0]
                                // Create new document
                                PdfDocument outputDocument = new PdfDocument(); outputDocument.Version = inputDocument.Version;

                                //bookmark should be title
                                outputDocument.Info.Title = bookMarkName;
                                outputDocument.Info.Creator = inputDocument.Creator;
                                 
                                // Add the page and save it
                                outputDocument.AddPage(child);
                            }
                            else 
                                outputDocument.AddPage(child);
                        
                            // bör identifiera bokmärkesnamnet
                            
                        }

                        Console.WriteLine(child.Elements.GetString("/Title"));

                        // FIXME: get page numbers?

                    }

                }

            }
            catch(Exception e) 
            {
                Console.Error.WriteLine(e.Message);
                Console.Error.WriteLine(e.StackTrace);
            }
        }

    }

//Copied from: split PDF into multiple files in C# - Stack Overflow - <https://stackoverflow.com/questions/3574505/split-pdf-into-multiple-files-in-c-sharp>


private static void saveFile(string fileName, params byte[][] bytes)
{
    try
    {
        PdfDocument outputDocument = new PdfDocument();
        for (int i = 0; i < bytes.Length; i++)
        {
            using (MemoryStream stream = new MemoryStream(bytes[i]))
            {
                PdfDocument inputDocument = PdfReader.Open(stream, PdfDocumentOpenMode.Import);
                foreach (PdfPage page in inputDocument.Pages)
                {
                    outputDocument.AddPage(page); //throws the exception !!!
                }
            }
        }
        outputDocument.Save(fileName);  
    }
    catch (Exception ex)
    {
        throw new Exception("Erreur lors de l'enregistrement du fichier", ex);
    }
}

//Copied from: c# - Combining multiple PDFs using PDFSharp - Stack Overflow - 2020-09-15 15:35:54 - <https://stackoverflow.com/questions/4995263/combining-multiple-pdfs-using-pdfsharp>

