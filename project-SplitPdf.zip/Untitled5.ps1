﻿Clear-Host


function Start-App{

param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript({
            if( $_.Extension -ine ".pdf" ){ 
                throw "The file $($_.FullName) is not a pdf file."
            } 
            if(-not (Test-Path $_.FullName)) {
                throw "The file '$($_.FullName)' does not exist!"
            }
            $true
        })]
                [System.IO.FileInfo[]]$File,
                [Parameter(Mandatory=$true)]
                [ValidateNotNullOrEmpty()]
                [System.IO.FileInfo]$DestinationFile
        )
    Add-Type -LiteralPath "C:\Users\crbk01\OneDrive - Region Gotland\Project Shelf\PdfSharp-gdi.dll"

    if((Test-Path $DestinationFile.FullName) -and $DestinationFile.IsReadOnly -and -not $Force) {
        throw "Destination file '$($DestinationFile.FullName)' is read only"
    }

    [System.IO.DirectoryInfo]$DestinationDirectory = $DestinationFile | Split-Path -Parent
    if(-not (Test-Path $DestinationDirectory)) {
        try {
            $DestinationDirectory = New-Item -Path $DestinationDirectory.FullName -ItemType Directory -Force:$Force
        } catch {
            throw "Error in $($MyInvocation.MyCommand.Name). Could not create directory '$($Path)'. $Error[0]"
        }
    }
    	
	$document = [PdfSharp.Pdf.IO.PdfReader]::Open($file.FullName, [PdfSharp.Pdf.IO.PdfDocumentOpenMode]::Import)
    $curentTitle
    $currentDoc
    Foreach($rootb In $document.Outlines)
    {   
     Write-Host $rootb.Title
      Write-Host $curentTitle
      Write-Host $currentDoc
       
        if ((!(("\" + $rootb.Title + ".pdf") -eq $curentTitle )) -AND (!($curentTitle -eq "")))
        {
            Write-Host "---------------------------------------------savepast---------------------------------------------" 
            $output =  Join-Path -Path $DestinationFile.Directory -ChildPath $curentTitle
            Write-Host $output
            $currentDoc.save($output);$currentDoc.close
        }          
        if (!(("\" + $rootb.Title + ".pdf") -eq $curentTitle ))
        {       
            Write-Host "---------------------------------------------New---------------------------------------------" 
            $newdocx = New-Object PdfSharp.Pdf.PdfDocument
            $newdocx.Version = $document.Version;
            $newdocx.Info.Title = $document.Info.Title
            $newdocx.Info.Creator = $document.Info.Creator
            $currentDoc = $newdocx
        }
            Write-Host "---------------------------------------------addPages---------------------------------------------" 
            $currentDoc.AddPage($rootb.DestinationPage)

            $curentTitle = "\" + $rootb.Title + ".pdf"
            Write-Host $currentTitle  
            
    }
    Write-Host "---------------------------------------------saveToOutput---------------------------------------------" 
    $newdocx.save($output);$newdocx.close;Remove-Variable newdocx

}


   start-app 'C:\Users\crbk01\Desktop\Ny mapp\xs.pdf' 'C:\Users\crbk01\Desktop\Ny mapp\Ny mapp\s.pdf'